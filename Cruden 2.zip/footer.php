
<div id="wrap">

	<!-- footer starts -->			
	<div id="footer-wrap"><div id="footer">				

	
			<p>
			&copy; 2014 Photo Stack

            &nbsp;&nbsp;&nbsp;&nbsp; 
			
			<a href="about.php">About Us</a> |
   		    <a href="help.php">Contact Us</a> |
	   	    <a href="Product.php">Product</a> |
			<a href="My Account.php">Account page</a> |
			<a href="transaction.php">Transaction page</a> |
			<a href="categories.php">Categories</a> |
			<a href="userprofile.php">User Profile</a> |
			<a href="orderconfirmation.php">Order Confirmation</a> |
			<a href="404.php">404 Custom</a> |
			<a href="admin.php">Admin Login</a> |
			<a href="basket.php">Basket</a> |
			</p>
		<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-53eb95ad08fd6189"></script>

<!-- Go to www.addthis.com/dashboard to customize your tools -->
<div class="addthis_horizontal_follow_toolbox"></div></div>	
	</div></div>
	<!-- footer ends-->	

<!-- wrap ends here -->