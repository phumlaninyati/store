<div id="maincontainer">
<div id= "banner1">
	<a href = "../Cruden"><img src = "photos/logo.png" alt = "Photo Stack" /></a>
	
</div>


<div id="container1">
<FORM METHOD="LINK" ACTION="register.php">
<INPUT TYPE="submit" VALUE="Register">
</FORM>

</div>
<div id="container02">
<FORM METHOD="LINK" ACTION="login.php">
<INPUT TYPE="submit" VALUE="Login">
</FORM>
</div>

<div id="container03">
<img src="css/search.png" alt="placeholder image">
</div>

<div id="container04">
<FORM METHOD="LINK" ACTION="basket.php">
<INPUT TYPE="submit" VALUE="Basket">
</div>

<div id="container05">
<img src="css/checkout.png" alt="placeholder image">
</div>
</maincontainer>