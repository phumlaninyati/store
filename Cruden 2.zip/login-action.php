<?php
include_once 'admin-class.php';
$admin = new itg_admin();
$admin->_login_action();
