<div id="maincontainer">
<div id= "banner1">
	<a href = "../Project"><img src = "css/PS - Logo(b).png" alt = "Photo Stack" /></a>
	
</div>

<div id="container1">
<a>Register here</a>

</div>
<div id="container02">
<img src="css/login.png" alt="placeholder image">
</div>

<div id="container03">
<img src="css/search.png" alt="placeholder image">
</div>

<div id="container04">
<img src="css/basket.png" alt="placeholder image">
</div>

<div id="container05">
<img src="css/checkout.png" alt="placeholder image">
</div>
</maincontainer>


