
<div id="wrap">

	<!-- footer starts -->			
	<div id="footer-wrap"><div id="footer">				
			
			<p>
			&copy; 2014 Photo Stack

            &nbsp;&nbsp;&nbsp;&nbsp; 
			
			<a href="about.php">About Us</a> |
   		    <a href="help.php">Contact Us</a> |
	   	    <a href="Product.php">Product</a> |
			<a href="My Account.php">Account page</a> |
			<a href="transaction.php">Transaction page</a> |
			<a href="categories.php">Categories</a> |
			</p>
			
	</div></div>
	<!-- footer ends-->	

<!-- wrap ends here -->