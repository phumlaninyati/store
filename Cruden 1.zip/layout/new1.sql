SELECT * 
FROM user_cons_colmns
WHERE table_name = '<users>'