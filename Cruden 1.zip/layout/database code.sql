create table user (
name varchar(20) primary key,
description text,
is_lit boolean );
